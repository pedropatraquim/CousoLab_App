Danish Bricks is a decorative font inspired by the famous "Danish building bricks". All characters are inspired by shapes that can actually be assembled with parts and remain assembled without assistance. The font has only uppercase letters and numerals, no special characters.

The font is 100% free

https://www.instagram.com/rafaelhoffmann.dsg/