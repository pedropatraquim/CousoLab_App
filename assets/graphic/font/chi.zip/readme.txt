Chi is a handwritten, bubbly typeface that can be utilized in a variety of creative projects. This font is free for PERSONAL and COMMERCIAL use.

Feel free to contact the designer with questions, comments, and/or inquiries: chloeachann[at]gmail.com

https://www.behance.net/chloeachan
